# Instale com:
# pip install dash pandas requests plotly

import pandas as pd
import requests
from dash import Dash, dcc, html, Input, Output
import plotly.express as px

# ========== ETAPA 1: EXTRAÇÃO E TRANSFORMAÇÃO ==========
url = "https://raw.githubusercontent.com/ingridcristh/challenge2-data-science/main/TelecomX_Data.json"
data = requests.get(url).json()
df = pd.DataFrame(data)

df_full = pd.concat([
    df.drop(['customer', 'phone', 'internet', 'account'], axis=1),
    df['customer'].apply(pd.Series),
    df['phone'].apply(pd.Series),
    df['internet'].apply(pd.Series),
    df['account'].apply(pd.Series)
], axis=1)

charges = df_full['Charges'].apply(pd.Series)
df_full['Charges_Monthly'] = pd.to_numeric(charges['Monthly'], errors='coerce')
df_full['Charges_Total'] = pd.to_numeric(charges['Total'], errors='coerce')
df_full.drop(columns=['Charges'], inplace=True)
df_full.dropna(subset=['Charges_Total'], inplace=True)
df_full['SeniorCitizen'] = df_full['SeniorCitizen'].astype(int)

# ========== ETAPA 2: DASHBOARD ==========
app = Dash(__name__)
server = app.server  # necessário para deploy

# Layout
app.layout = html.Div([
    html.H1("📊 Dashboard - Análise de Churn da Telecom X", style={'textAlign': 'center'}),

    html.Div([
        html.Label("🔍 Filtro por Tipo de Contrato:"),
        dcc.Dropdown(
            options=[{"label": c, "value": c} for c in df_full['Contract'].unique()],
            value=None,
            placeholder="Selecione um tipo de contrato",
            id='filtro-contrato'
        ),
    ], style={'width': '40%', 'margin': '20px auto'}),

    dcc.Graph(id='grafico-churn-contrato'),

    html.Div([
        dcc.Graph(id='grafico-box-tenure'),
        dcc.Graph(id='grafico-pagamento')
    ], style={'display': 'flex', 'flexWrap': 'wrap', 'justifyContent': 'space-around'}),

    dcc.Graph(id='grafico-heatmap')
])

# ========== CALLBACKS ==========
@app.callback(
    Output('grafico-churn-contrato', 'figure'),
    Input('filtro-contrato', 'value')
)
def atualizar_grafico_churn(filtro):
    df_filtered = df_full[df_full['Contract'] == filtro] if filtro else df_full
    fig = px.histogram(df_filtered, x="InternetService", color="Churn",
                       barmode="group", text_auto=True,
                       title="Churn por Tipo de Internet")
    return fig

@app.callback(
    Output('grafico-box-tenure', 'figure'),
    Input('filtro-contrato', 'value')
)
def atualizar_box_tenure(filtro):
    df_filtered = df_full[df_full['Contract'] == filtro] if filtro else df_full
    fig = px.box(df_filtered, x='Churn', y='tenure', color='Churn',
                 title="Tempo de Permanência por Churn")
    return fig

@app.callback(
    Output('grafico-pagamento', 'figure'),
    Input('filtro-contrato', 'value')
)
def atualizar_pagamento(filtro):
    df_filtered = df_full[df_full['Contract'] == filtro] if filtro else df_full
    fig = px.histogram(df_filtered, x='PaymentMethod', color='Churn',
                       barmode='group', title="Churn por Método de Pagamento")
    return fig

@app.callback(
    Output('grafico-heatmap', 'figure'),
    Input('filtro-contrato', 'value')
)
def atualizar_heatmap(filtro):
    df_filtered = df_full[df_full['Contract'] == filtro] if filtro else df_full
    corr = df_filtered[['tenure', 'Charges_Monthly', 'Charges_Total']].corr()
    fig = px.imshow(corr, text_auto=True, title="Correlação entre Variáveis Numéricas")
    return fig

# ========== EXECUTAR ==========
if __name__ == '__main__':
    app.run(debug=True)

